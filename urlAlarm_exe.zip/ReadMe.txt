The program opens a URL in a new browser window at the specified time.  This is useful if, for example, you would like to set a video to start when you wake in the morning.  

* If a new window can't be opened, the program will attempt to open a new tab, then use an open window in that order. 
* The time is accurate to the nearest minute and can only be set for within the next 24 hours.
* The menu can be bypassed by starting the program with arguments <url> <hour> <minute> with the hour given in 24-hour form.  

Requires the following DLL to operate: 
   USER32.dll - C:\WINDOWS\system32\USER32.dll
   SHELL32.dll - C:\WINDOWS\system32\SHELL32.dll
   ADVAPI32.dll - C:\WINDOWS\system32\ADVAPI32.dll
   WS2_32.dll - C:\WINDOWS\system32\WS2_32.dll
   GDI32.dll - C:\WINDOWS\system32\GDI32.dll
   KERNEL32.dll - C:\WINDOWS\system32\KERNEL32.dll